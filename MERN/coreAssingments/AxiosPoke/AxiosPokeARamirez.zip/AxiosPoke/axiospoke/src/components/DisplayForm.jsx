import React from 'react'

const DisplayForm = () => {
    return (
        <fieldset>
            <legend>DisplayForm.jsx</legend>
            <div>Pokemon Go Here</div>
        </fieldset>
    )
}

export default DisplayForm