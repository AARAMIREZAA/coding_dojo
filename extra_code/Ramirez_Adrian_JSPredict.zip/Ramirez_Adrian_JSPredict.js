//Prediction 1 console.log(i was born in 1980);
//Prediction 2 console.log(1980);
//Prediction 3 console.log(30);