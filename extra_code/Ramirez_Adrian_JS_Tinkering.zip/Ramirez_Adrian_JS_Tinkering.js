var HeightofChild = 5
    function displayIfChildIsAbleToRideTheRollerCoaster() {
    if (var HeightofChild >= 4)
    console.log("Get on that ride, kiddo!")
}
    else {
        console.log("Sorry kiddo. Maybe next year.")
}