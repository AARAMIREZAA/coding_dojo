class User:
    def __init__(self, name, email, password):
        self.name = name
        self.email = email
        self.password = password
        self.account_balance = 0

    def deposit(self, amount):
        self.account_balance += amount

    def withdrawl(self, amount):
        self.account_balance -= amount

    def display_user_balance(self):
        print(self.account_balance)

    def greeting(self):
        print(f"Hello {self.name} Welcome back TO Coding Dojo Credit Union")
        

adrian = User("adrian", "adog@aol.com", "handsomecoder123")
tyler = User("tyler", "tmax@gmail.com", "luvsCats")
amber = User("amber", "amberH@icloud.com", "POamberOP")
adrian.greeting()

adrian.deposit(100)
adrian.deposit(100)
adrian.deposit(50)
adrian.withdrawl(170)
adrian.display_user_balance()

tyler.greeting()
tyler.deposit(1000)
tyler.deposit(530)
tyler.withdrawl(10)
tyler.withdrawl(80)
tyler.display_user_balance()

amber.greeting()
amber.deposit(2500)
amber.withdrawl(1000)
amber.withdrawl(1500)
amber.withdrawl(7000)
amber.display_user_balance()