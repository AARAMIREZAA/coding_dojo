from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'asdfasdfkjasdlfkjasd'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def create_user():
    print(request.form)
    session['name'] = request.form['name']
    session ['location'] = request.form['location']
    session ['language']= request.form['language']
    session ['comment'] = request.form['comment']
    return redirect('/result')

@app.route("/result")
def show_info():
    return render_template("result.html", name_on_template = session['name'], location_on_template = session['location'],
    language_on_template = session['language'],comment_on_template = session['comment'])


if __name__ == '__main__':
    app.run(debug=True)