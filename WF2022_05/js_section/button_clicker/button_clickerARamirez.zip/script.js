function alert() {
    alert();
}

function disappear(element) {
    element.remove();
}
function change(element){
    element.innerText = "Log Out";
}
