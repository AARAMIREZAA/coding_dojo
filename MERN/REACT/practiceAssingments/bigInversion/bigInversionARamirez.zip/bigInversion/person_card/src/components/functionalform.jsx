// import dependecies
import React from 'react'



// crete the functional component

const functionalform = (props) => { //define props as param
    return (
        <div>functionalform</div>
    )
}



// export the functional component
export default functionalform