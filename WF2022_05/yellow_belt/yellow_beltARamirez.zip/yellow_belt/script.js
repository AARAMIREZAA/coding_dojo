function disappear(element) {
    element.remove();
}
function addlikes(element){
    element.innerText++;
}
function petalert() {
    alert("You are looking for a dog!");
}
function petalert1() {
    alert("You are looking for a cats!");
}
function petalert2() {
    alert("You are looking for a bird!");
}