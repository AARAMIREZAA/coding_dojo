// Print odds 1-20

// function PrintOdds(){
//     for (var i = 1; i <= 20; i+=2){
//         console.log(i)
//     }
// }
// PrintOdds();

// Decrease multiples of 3

// function decreaseMult(){
//     for (var i = 100; i > 0; i--){
//         if (i % 3 == 0){
//          console.log(i)
//         }
//     }
// }
// decreaseMult();

// Print the sequence

// function decreaseBy(){
//     for (var i =4; i >= -3.5; i-=1.5){
//         console.log(i)
//     }
// }
// decreaseBy();

// Sigma

// function addValues(){
//     var sumSoFar = 0;
//     for (var i = 0; i <= 100; i++){
//     sumSoFar = sumSoFar + i;
//     console.log(i)
//     }
//     console.log(sumSoFar)
// }

// addValues();

// Factorial

function multiplyVal(){
    var product = 1;
    for (var i = 1; i <= 12; i++){
        product = product * i;
        console.log(i)
        console.log(product)
    }
}
multiplyVal();


//Made by Adrian Ramirez