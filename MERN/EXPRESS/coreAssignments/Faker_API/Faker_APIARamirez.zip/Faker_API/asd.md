npm i


npm -i express core mogoose

nodemon server.js


inside config, create file
mongoose.config.js

copy code from coding dojo
import mongoose on the file
rename database

copy code from coding dojo
require("serverblahblah) start your mongoose config